#include <stdio.h>

int main() {
  printf("Hello, Codedang!\n");
  return 0;
}